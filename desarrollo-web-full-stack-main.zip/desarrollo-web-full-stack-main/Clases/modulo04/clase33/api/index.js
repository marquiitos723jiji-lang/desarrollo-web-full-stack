import express from "express"
import routes from "./routes/index.js"


const app = express()

app.use(express.json())

app.listen(3000)

app.use("/", routes) // TODAS las peticiones a http:localhost:3000/ van a usar routes
