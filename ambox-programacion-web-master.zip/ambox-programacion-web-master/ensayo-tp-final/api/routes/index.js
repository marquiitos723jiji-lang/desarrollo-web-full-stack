import { Router } from "express"
import productRouter from "./productRouter.js"
import userRouter from "./userRouter.js"
import cors from "cors"

const router = Router()

router.use("/productos", productRouter) 
router.use("/usuarios", userRouter) 

export default router