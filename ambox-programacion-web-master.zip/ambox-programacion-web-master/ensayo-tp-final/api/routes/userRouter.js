import express from "express";

import {
    getUsers,
    getUser,
    create,
    update,
    remove,
    login
} from "../controllers/userController.js";

const router = express.Router();

router.post("/login", login);

// Obtener todos
router.get("/", getUsers);

// Obtener uno
router.get("/:id", getUser);

// Crear
router.post("/", create);

// Actualizar
router.put("/:id", update);

// Eliminar
router.delete("/:id", remove);

export default router;