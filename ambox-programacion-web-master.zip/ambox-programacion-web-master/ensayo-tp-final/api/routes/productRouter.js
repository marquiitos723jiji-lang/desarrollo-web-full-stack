import express from "express";

import {
    getProducts,
    getProduct,
    createProduct,
    updateProduct,
    deleteProduct
} from "../controllers/productController.js";

const productRouter = express.Router();

// GET Todos los productos
productRouter.get("/", getProducts);

// GET Un producto
productRouter.get("/:id", getProduct);

// POST Crear producto
productRouter.post("/", createProduct);

// PUT Actualizar producto
productRouter.put("/:id", updateProduct);

// DELETE Eliminar producto
productRouter.delete("/:id", deleteProduct);

export default productRouter;