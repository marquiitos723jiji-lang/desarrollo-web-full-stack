import mongoose from "mongoose";

const productSchema = new mongoose.Schema({

    nombre: String,

    descripcion: String,

    precio: Number,

    stock: Number,

    categoria: String,

    imagen: String

});

const Product = mongoose.model(
    "productos",
    productSchema
);

export default Product;