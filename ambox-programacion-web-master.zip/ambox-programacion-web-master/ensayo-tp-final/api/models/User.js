import mongoose from "mongoose";

const userSchema = new mongoose.Schema({
    name: String,
    email: String,
    password: String,
    role: {
        type: String,
        enum: ["admin", "seller", "user"],
        default: "user",
    },
});

export default mongoose.model("usuarios", userSchema);