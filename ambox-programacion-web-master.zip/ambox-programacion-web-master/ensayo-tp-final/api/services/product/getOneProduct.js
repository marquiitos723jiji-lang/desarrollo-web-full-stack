import Product from "../../models/Product.js";

export default async function getOneProduct(id) {
    return await Product.findById(id);
}