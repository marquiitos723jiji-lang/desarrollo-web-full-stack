import Product from "../../models/Product.js";

export default async function updateProduct(id, datos) {
    return await Product.findByIdAndUpdate(
        id,
        datos,
        { new: true }
    );
}