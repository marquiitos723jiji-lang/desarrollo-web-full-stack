import Product from "../../models/Product.js";

export default async function getAllProducts() {
    return await Product.find();
}