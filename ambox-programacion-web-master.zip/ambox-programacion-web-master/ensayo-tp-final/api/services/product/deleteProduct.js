import Product from "../../models/Product.js";

export default async function deleteProduct(id) {
    return await Product.findByIdAndDelete(id);
}