import Product from "../../models/Product.js";

export default async function createProduct(producto) {
    return await Product.create(producto);
}