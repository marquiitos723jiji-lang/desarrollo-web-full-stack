import User from "../../models/User.js";

export default async function createUser(usuario){

    return await User.create(usuario);

}