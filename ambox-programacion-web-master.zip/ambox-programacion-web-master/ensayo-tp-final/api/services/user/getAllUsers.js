import User from "../../models/User.js";

export default async function getAllUsers(){

    return await User.find();

}