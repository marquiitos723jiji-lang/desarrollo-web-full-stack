import User from "../../models/User.js";

export default async function deleteUser(id){

    return await User.findByIdAndDelete(id);

}