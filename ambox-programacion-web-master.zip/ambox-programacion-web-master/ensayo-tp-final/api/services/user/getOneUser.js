import User from "../../models/User.js";

export default async function getOneUser(id){

    return await User.findById(id);

}