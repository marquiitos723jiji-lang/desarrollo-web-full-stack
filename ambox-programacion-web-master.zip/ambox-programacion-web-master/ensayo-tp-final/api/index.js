import express from "express";
import mongoose from "mongoose";
import cors from "cors";

import routes from "./routes/index.js";

const app = express();

app.use(cors());
app.use(express.json());

mongoose
    .connect("CADENA_DE_ATLAS")
    .then(() => {

        console.log("Mongo conectado");

        app.use("/", routes);

        app.listen(3000, () => {
            console.log("Servidor iniciado");
        });

    });