import getAllProducts from "../services/products/getAllProducts.js";
import getOneProduct from "../services/products/getOneProduct.js";
import createProductService from "../services/products/createProduct.js";
import updateProductService from "../services/products/updateProduct.js";
import deleteProductService from "../services/products/deleteProduct.js";

export async function getProducts(req, res) {
    const productos = await getAllProducts();
    res.json(productos);
}

export async function getProduct(req, res) {
    const producto = await getOneProduct(req.params.id);

    if (!producto) {
        return res.status(404).json({
            mensaje: "Producto no encontrado"
        });
    }

    res.json(producto);
}

export async function createProduct(req, res) {
    const producto = await createProductService(req.body);

    res.status(201).json(producto);
}

export async function updateProduct(req, res) {
    const producto = await updateProductService(
        req.params.id,
        req.body
    );

    if (!producto) {
        return res.status(404).json({
            mensaje: "Producto no encontrado"
        });
    }

    res.json(producto);
}

export async function deleteProduct(req, res) {
    const producto = await deleteProductService(req.params.id);

    if (!producto) {
        return res.status(404).json({
            mensaje: "Producto no encontrado"
        });
    }

    res.json({
        mensaje: "Producto eliminado correctamente"
    });
}