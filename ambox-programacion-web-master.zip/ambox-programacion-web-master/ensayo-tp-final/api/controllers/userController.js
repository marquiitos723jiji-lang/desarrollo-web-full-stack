import getAllUsers from "../services/user/getAllUsers.js";
import getOneUser from "../services/user/getOneUser.js";
import createUser from "../services/user/createUser.js";
import updateUser from "../services/user/updateUser.js";
import deleteUser from "../services/user/deleteUser.js";

export async function login(req, res) {

    const { email, password } = req.body;

    const usuario = await User.findOne({
        email,
        password
    });

    if (!usuario) {

        return res.status(401).json({
            mensaje: "Credenciales incorrectas"
        });

    }

    res.json(usuario);
}

// GET /usuarios
export async function getUsers(req, res) {
    try {
        const usuarios = await getAllUsers();

        res.status(200).json(usuarios);
    } catch (error) {
        res.status(500).json({
            mensaje: "Error al obtener los usuarios",
            error: error.message,
        });
    }
}

// GET /usuarios/:id
export async function getUser(req, res) {
    try {
        const usuario = await getOneUser(req.params.id);

        if (!usuario) {
            return res.status(404).json({
                mensaje: "Usuario no encontrado",
            });
        }

        res.status(200).json(usuario);
    } catch (error) {
        res.status(500).json({
            mensaje: "Error al obtener el usuario",
            error: error.message,
        });
    }
}

// POST /usuarios
export async function create(req, res) {
    try {
        const usuario = await createUser(req.body);

        res.status(201).json(usuario);
    } catch (error) {
        res.status(500).json({
            mensaje: "Error al crear el usuario",
            error: error.message,
        });
    }
}

// PUT /usuarios/:id
export async function update(req, res) {
    try {
        const usuario = await updateUser(
            req.params.id,
            req.body
        );

        if (!usuario) {
            return res.status(404).json({
                mensaje: "Usuario no encontrado",
            });
        }

        res.status(200).json(usuario);
    } catch (error) {
        res.status(500).json({
            mensaje: "Error al actualizar el usuario",
            error: error.message,
        });
    }
}

// DELETE /usuarios/:id
export async function remove(req, res) {
    try {
        const usuario = await deleteUser(req.params.id);

        if (!usuario) {
            return res.status(404).json({
                mensaje: "Usuario no encontrado",
            });
        }

        res.status(200).json({
            mensaje: "Usuario eliminado correctamente",
        });
    } catch (error) {
        res.status(500).json({
            mensaje: "Error al eliminar el usuario",
            error: error.message,
        });
    }
}