export default function UserForm({

    nuevoUsuario,

    setNuevoUsuario,

    guardarUsuario,

    editandoId

}) {

    function cambiar(e){

        setNuevoUsuario({

            ...nuevoUsuario,

            [e.target.name]:e.target.value

        });

    }

    return(

        <div>

            <input

                name="name"

                placeholder="Nombre"

                value={nuevoUsuario.name}

                onChange={cambiar}

            />

            <input

                name="email"

                placeholder="Email"

                value={nuevoUsuario.email}

                onChange={cambiar}

            />

            <input

                name="password"

                placeholder="Contraseña"

                type="password"

                value={nuevoUsuario.password}

                onChange={cambiar}

            />

            <button

                onClick={guardarUsuario}

            >

                {

                    editandoId

                    ?

                    "Actualizar Usuario"

                    :

                    "Crear Usuario"

                }

            </button>

        </div>

    );

}