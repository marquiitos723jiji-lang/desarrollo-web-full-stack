export default function UserCard({

    usuario,

    editarUsuario,

    eliminarUsuario

}){

    return(

        <div
            style={{
                border:"1px solid gray",
                margin:"10px",
                padding:"15px"
            }}
        >

            <h2>{usuario.name}</h2>

            <p>{usuario.email}</p>

            <button

                onClick={()=>editarUsuario(usuario)}

            >

                Editar

            </button>

            <button

                onClick={()=>eliminarUsuario(usuario._id)}

            >

                Eliminar

            </button>

        </div>

    );

}