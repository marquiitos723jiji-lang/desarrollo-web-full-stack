import { Navigate } from "react-router-dom";

export default function PrivateRoute({ children }) {

    const usuario = JSON.parse(
        localStorage.getItem("usuario")
    );

    if (!usuario) {

        return <Navigate to="/" />;

    }

    if (
        usuario.role !== "admin" &&
        usuario.role !== "seller"
    ) {

        return <Navigate to="/" />;

    }

    return children;

}