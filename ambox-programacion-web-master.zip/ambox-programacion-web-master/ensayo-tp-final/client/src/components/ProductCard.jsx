export default function ProductCard({

    producto,

    eliminarProducto,

    editarProducto

}) {

    return (

        <div
            style={{
                border:"1px solid gray",
                margin:"20px",
                padding:"20px",
                width:"300px"
            }}
        >

            <img

                src={producto.imagen}

                width="200"

            />

            <h2>

                {producto.nombre}

            </h2>

            <p>

                {producto.descripcion}

            </p>

            <h3>

                ${producto.precio}

            </h3>

            <p>

                Stock: {producto.stock}

            </p>

            <p>

                Categoría: {producto.categoria}

            </p>

            <button

                onClick={() => editarProducto(producto)}

            >

                Editar

            </button>

            <button

                onClick={() => eliminarProducto(producto._id)}

            >

                Eliminar

            </button>

        </div>

    );

}