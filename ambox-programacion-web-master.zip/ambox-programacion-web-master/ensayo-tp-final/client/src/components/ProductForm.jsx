export default function ProductForm({

    producto,

    setProducto,

    guardarProducto,

    editandoId

}) {

    function cambiar(e){

        setProducto({

            ...producto,

            [e.target.name]:e.target.value

        });

    }

    return (

        <div>

            <input

                placeholder="Nombre"

                name="nombre"

                value={producto.nombre}

                onChange={cambiar}

            />

            <input

                placeholder="Descripción"

                name="descripcion"

                value={producto.descripcion}

                onChange={cambiar}

            />

            <input

                placeholder="Precio"

                name="precio"

                value={producto.precio}

                onChange={cambiar}

            />

            <input

                placeholder="Stock"

                name="stock"

                value={producto.stock}

                onChange={cambiar}

            />

            <input

                placeholder="Categoría"

                name="categoria"

                value={producto.categoria}

                onChange={cambiar}

            />

            <input

                placeholder="Imagen"

                name="imagen"

                value={producto.imagen}

                onChange={cambiar}

            />

            <button onClick={guardarProducto}>

                {

                    editandoId

                    ? "Actualizar"

                    : "Crear"

                }

            </button>

        </div>

    );

}