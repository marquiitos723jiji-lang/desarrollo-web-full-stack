import { useEffect, useState } from "react";
import axios from "axios";

import ProductCard from "../components/ProductCard";
import ProductForm from "../components/ProductForm";

export default function Productos() {

    const [productos, setProductos] = useState([]);

    const [editandoId, setEditandoId] = useState(null);

    const [producto, setProducto] = useState({
        nombre: "",
        descripcion: "",
        precio: "",
        stock: "",
        categoria: "",
        imagen: "",
    });

    async function obtenerProductos() {
        const res = await axios.get(
            "http://localhost:3000/productos"
        );

        setProductos(res.data);

    }

    useEffect(() => {

        obtenerProductos();

    }, []);

    async function guardarProducto() {

        if (editandoId) {

            const res = await axios.put(

                `http://localhost:3000/productos/${editandoId}`,

                producto

            );

            setProductos(

                productos.map((p) =>
                    p._id === editandoId
                        ? res.data
                        : p
                )

            );

            setEditandoId(null);

        } else {

            const res = await axios.post(

                "http://localhost:3000/productos",

                producto

            );

            setProductos([
                ...productos,
                res.data
            ]);

        }

        setProducto({
            nombre: "",
            descripcion: "",
            precio: "",
            stock: "",
            categoria: "",
            imagen: "",
        });

    }

    async function eliminarProducto(id) {

        await axios.delete(
            `http://localhost:3000/productos/${id}`
        );

        setProductos(
            productos.filter((p) => p._id !== id)
        );

    }

    function editarProducto(producto) {

        setProducto(producto);

        setEditandoId(producto._id);

    }

    return (

        <>

            <h1>Productos</h1>

            <ProductForm

                producto={producto}

                setProducto={setProducto}

                guardarProducto={guardarProducto}

                editandoId={editandoId}

            />

            <hr />

            <div className="grid">

                {

                    productos.map((producto) => (

                        <ProductCard

                            key={producto._id}

                            producto={producto}

                            editarProducto={editarProducto}

                            eliminarProducto={eliminarProducto}

                        />

                    ))

                }

            </div>

        </>

    );

}