import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export default function Login() {

    const navigate = useNavigate();

    const [email, setEmail] = useState("");

    const [password, setPassword] = useState("");

    async function iniciarSesion() {

        try {

            const res = await axios.post(
                "http://localhost:3000/usuarios/login",
                {
                    email,
                    password
                }
            );

            localStorage.setItem(
                "usuario",
                JSON.stringify(res.data)
            );

            navigate("/productos");

        } catch {

            alert("Email o contraseña incorrectos");

        }

    }

    return (

        <div>

            <h1>Login</h1>

            <input
                placeholder="Email"
                value={email}
                onChange={(e)=>setEmail(e.target.value)}
            />

            <input
                type="password"
                placeholder="Contraseña"
                value={password}
                onChange={(e)=>setPassword(e.target.value)}
            />

            <button
                onClick={iniciarSesion}
            >
                Ingresar
            </button>

        </div>

    );

}