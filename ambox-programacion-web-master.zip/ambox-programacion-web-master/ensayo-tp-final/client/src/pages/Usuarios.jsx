import { useEffect, useState } from "react";
import axios from "axios";

import UserCard from "../components/UserCard";
import UserForm from "../components/UserForm";

export default function Usuarios() {

    const [usuarios, setUsuarios] = useState([]);

    const [editandoId, setEditandoId] = useState(null);

    const [nuevoUsuario, setNuevoUsuario] = useState({
        name: "",
        email: "",
        password: "",
    });

    async function obtenerUsuarios() {

        const res = await axios.get(
            "http://localhost:3000/usuarios"
        );

        setUsuarios(res.data);

    }

    useEffect(() => {

        obtenerUsuarios();

    }, []);

    async function guardarUsuario() {

        if (editandoId) {

            const res = await axios.put(

                `http://localhost:3000/usuarios/${editandoId}`,

                nuevoUsuario

            );

            setUsuarios(

                usuarios.map((u) =>
                    u._id === editandoId
                        ? res.data
                        : u
                )

            );

            setEditandoId(null);

        } else {

            const res = await axios.post(

                "http://localhost:3000/usuarios",

                nuevoUsuario

            );

            setUsuarios([
                ...usuarios,
                res.data
            ]);

        }

        setNuevoUsuario({
            name: "",
            email: "",
            password: "",
        });

    }

    async function eliminarUsuario(id) {

        await axios.delete(
            `http://localhost:3000/usuarios/${id}`
        );

        setUsuarios(

            usuarios.filter((u) => u._id !== id)

        );

    }

    function editarUsuario(usuario) {

        setNuevoUsuario({

            name: usuario.name,

            email: usuario.email,

            password: usuario.password,

        });

        setEditandoId(usuario._id);

    }

    return (

        <>

            <h1>Usuarios</h1>

            <UserForm

                nuevoUsuario={nuevoUsuario}

                setNuevoUsuario={setNuevoUsuario}

                guardarUsuario={guardarUsuario}

                editandoId={editandoId}

            />

            <hr />

            {

                usuarios.map((usuario) => (

                    <UserCard

                        key={usuario._id}

                        usuario={usuario}

                        editarUsuario={editarUsuario}

                        eliminarUsuario={eliminarUsuario}

                    />

                ))

            }

        </>

    );

}