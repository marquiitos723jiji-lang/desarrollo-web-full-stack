import { BrowserRouter, Routes, Route } from "react-router-dom";

import Login from "./pages/Login";
import Productos from "./pages/Productos";
import Usuarios from "./pages/Usuarios";

import PrivateRoute from "./components/PrivateRoute";

function App() {

  return (
    <BrowserRouter>
      <Routes>
        <Route
          path="/"
          element={<Login />}
        />
        <Route
          path="/productos"
          element={
            <PrivateRoute>
              <Productos />
            </PrivateRoute>
          }
        />
        <Route
          path="/usuarios"
          element={
            <PrivateRoute>
              <Usuarios />
            </PrivateRoute>
          }
        />
        <Route path="/nada" element={
          !JSON.parse(localStorage.getItem("usuario"))
            ? <Login /> : <Usuarios />} />
            <Route path="/todo" element={
          JSON.parse(localStorage.getItem("usuario"))?.role !== "admin"
            ? <Login /> : <Productos />} />
      </Routes>
    </BrowserRouter>

  );

}

export default App;